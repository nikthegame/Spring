package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

@Controller
public class URIController {
	Account account;
	Transaction transaction;
	
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	
	@RequestMapping("/deposit")
	public String getDepositPage() {
		return "depositPage";
	}
	
	@RequestMapping("/withdraw")
	public String getWithdrawPage() {
		return "withdrawPage";
	}
	
	@ModelAttribute
	public Transaction getTransaction() {
		transaction = new Transaction();
		return transaction;
	}
	
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
}
}