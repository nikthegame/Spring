package com.cg.banking.beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Account {
	@Id
	@SequenceGenerator(sequenceName="account_seq",initialValue=10000,allocationSize=1, name = "account_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="account_seq")
	private long accountNo;
	private int pinNumber;
	@NotEmpty
	private String accountType;
	private String status;
	@NotNull
	private float accountBalance;
	
	@OneToMany(mappedBy="account",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	List<Transaction> trans;
	
	/*@OneToMany(mappedBy="account")
	public ArrayList<Transaction> getTrans() {
		return trans;
	}*/

/*	public void setTran(float amount,String transactionType) {
		Transaction t=new Transaction(transactionId_counter++, amount, transactionType) ;
		trans.add(t);
	}*/

	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	

	public Account(int pinNumber, String accountType, float accountBalance) {
		super();
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}


	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(int pinNumber, String accountType, String status,
			float accountBalance, long accountNo) {
		super();
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public long getAccountNo() {
		return accountNo;
	}
	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", accountType="
				+ accountType + ", status=" + status + ", accountBalance="
				+ accountBalance + ", accountNo=" + accountNo + ", trans="
				+ trans + "]";
	}
	

	public List<Transaction> getTrans() {
		return trans;
	}

	public void setTrans(List<Transaction> trans) {
		this.trans = trans;
	}

	/*public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}*/
}