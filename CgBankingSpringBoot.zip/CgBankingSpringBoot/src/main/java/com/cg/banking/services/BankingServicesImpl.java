package com.cg.banking.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired	
	AccountDAO accountDAO;
	@Autowired
	TransactionDAO transactionDAO;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		
		Account account1;
		account.setStatus("OPEN");
		if(account.getAccountBalance()<1000) throw new InvalidAmountException("Enter the right amount");
		if(!(account.getAccountType().equalsIgnoreCase("Savings")||account.getAccountType().equalsIgnoreCase("Current")))throw new InvalidAccountTypeException("Account Type Not Correct");
		else{		
			account1=accountDAO.save(account);
			
			return account1;
		}
	}

	public Transaction depositAmount(Transaction transaction,long accountNo)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		//Account account=accountDAO.findOne(transaction.getAccount().getAccountNo());
		//Transaction transaction = new Transaction(amount, accountDAO.findOne(accountNo));
		Transaction trans1;
		Account account = accountDAO.findById(accountNo).get();
		if(account==null)throw new AccountNotFoundException("Account Not Found");
		else {
			trans1 = transaction;
			trans1.setAccount(account);
			trans1 =  transactionDAO.save(trans1);
			account.setAccountBalance(account.getAccountBalance()+trans1.getAmount());
			accountDAO.save(account);
			return trans1;
		}
	}

@Override
	public Transaction withdrawAmount(Transaction transaction,long accountNo, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
	Account account = accountDAO.findById(accountNo).get();
	Transaction trans1;
	if(account==null)throw new AccountNotFoundException("Account Not Found");
	if(account.getPinNumber()!=pinNumber) throw new InvalidPinNumberException();
	if(account.getAccountBalance()-transaction.getAmount()<0) throw new InsufficientAmountException();
	else {
		transaction.setAccount(account);
		trans1 =  transactionDAO.save(transaction);
		account.setAccountBalance(account.getAccountBalance()-transaction.getAmount());
		accountDAO.save(account);
		return trans1;
	}
}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account acc1=accountDAO.findById(accountNoTo).get();
		Account acc2=accountDAO.findById(accountNoFrom).get();
		if(acc2.getPinNumber()!=pinNumber)throw new InvalidPinNumberException("Pin Number Not Found") ;
		else
		acc1.setAccountBalance(acc1.getAccountBalance()+transferAmount);
		acc2.setAccountBalance(acc2.getAccountBalance()-transferAmount);
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		if(accountDAO.findById(accountNo).get()==null)throw new AccountNotFoundException("Account Not Found");
		return accountDAO.findById(accountNo).get();
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		
	return accountDAO.findAll();
	
	}

	/*@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account acc=accountDAO.findOne(accountNo);
		if(acc==null)throw new AccountNotFoundException("Account Not Found");
		return acc.getTrans();
	}*/

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
			Account account =accountDAO.findById(accountNo).get();
			if(!(account.getStatus().equalsIgnoreCase("OPEN"))) throw new AccountNotFoundException("Account not found");
			else
				return account.getStatus();
	}
/*
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}*/

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
