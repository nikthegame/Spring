package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.banking.beans.Account;

public interface AccountDAO extends JpaRepository<Account, Long> {
	/*Account  save(Account account) throws SQLException;
Account findOne(long accountNo);
	ArrayList<Account> findAll();*/
}