package com.cg.banking.controllers;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class AccountController {
	@Autowired
	BankingServices bankingServices;
	Account account1;
	Transaction trans1;

	
	@RequestMapping("/registerAccount")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account, BindingResult result) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{		
		
		if(result.hasErrors())
				return new ModelAndView("registrationPage");
		
		account1 = bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account", account1);
	}
	@RequestMapping("/depositAmount")
	public ModelAndView depositAmountAction(@ModelAttribute Transaction transaction) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException{		
		transaction.setTransactionType("Deposit");
		transaction = bankingServices.depositAmount(transaction,account1.getAccountNo());
		return new ModelAndView("transactionSuccess", "transaction",transaction); //transaction
	}
	/*@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmountAction(@ModelAttribute Transaction transaction,@ModelAttribute int pinNumber) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{		
		transaction.setTransactionType("Withdraw");
		trans1 = bankingServices.withdrawAmount(transaction,account1.getAccountNo(),pinNumber);
		return new ModelAndView("transactionSuccess", "transaction",transaction); //transaction
	}*/
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmountAction(@ModelAttribute Transaction transaction,@RequestParam("pinNumber") int pinNumber) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{		
		transaction.setTransactionType("Withdraw");
		trans1 = bankingServices.withdrawAmount(transaction,account1.getAccountNo(),pinNumber);
		return new ModelAndView("transactionSuccess", "transaction",transaction);
	}
}	
