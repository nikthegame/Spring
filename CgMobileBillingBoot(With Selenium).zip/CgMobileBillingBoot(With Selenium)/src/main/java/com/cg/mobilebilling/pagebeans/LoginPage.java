package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {
	@FindBy(how = How.NAME, name="mobileNo")
	private WebElement mobileNo;
	@FindBy(how=How.ID,id="submit")
	private WebElement button;
	@FindBy(how=How.ID,id="errMsg")
	private WebElement actualErrMsg;
	public LoginPage() {
		super();
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getActualErrMsg() {
		return actualErrMsg.getText();
	}
	public void clickLogIn() {
		button.click();
	}
}
