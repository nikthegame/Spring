package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class signUpStepDefinition {
	
	private WebDriver driver;
	
	@Given("^User is on registrationPage$")
	public void user_is_on_registrationPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");		
	    driver = new ChromeDriver();
	    driver.get("http://localhost:5558/registration");
	}
	@When("^User enter valid details$")
	public void user_enter_valid_details() throws Throwable {
		By by = By.name("firstName");
		WebElement searchTxt = driver.findElement(by);
		searchTxt.sendKeys("Nikhil");
		
		by = By.name("lastName");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("Maheshwari");
		
		by = By.name("emailID");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("n@gmail.com");
		
		by = By.name("dateOfBirth");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("10/02/1995");
		
		by = By.name("BillingAddress.city");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("Kota");
		
		by = By.name("BillingAddress.state");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("Raj.");
		
		by = By.name("BillingAddress.pinCode");
		searchTxt = driver.findElement(by);
		searchTxt.sendKeys("15478");
		
		by = By.name("submit");
		searchTxt = driver.findElement(by);
	    searchTxt.click();
	}

	@Then("^User should be able to signup$")
	public void user_should_be_able_to_signup() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Registration Successful";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
	
}
