package com.cg.mobilebilling.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.security.auth.login.AccountException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.GeneratePdfReport;
import com.itextpdf.text.DocumentException;

@Controller
public class CustomerController {
	@Autowired 
	BillingServices service;
	Customer cust;
	PostpaidAccount account,account1;
	Bill bill2;
	int amount;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("registrationPage","errMsg","Enter correct details");
		try {
			int customerID=	service.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(),customer.getDateOfBirth(),customer.getBillingAddress().getCity(), customer.getBillingAddress().getState(), customer.getBillingAddress().getPinCode());
			cust = customer;
			cust.setCustomerID(customerID);
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("registrationPage", "errMsg", "Please Try Again");
		}
		return new ModelAndView("registrationSuccessPage", "customer", customer);
	}

	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomerAction(@ModelAttribute Customer customer) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		try{
			service.deleteCustomer(customer.getCustomerID());
		}
		catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("deleteCustomerPage","errMsg","Customer does not exist");
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("deleteCustomerPage","errMsg","Please Try Again");
		}
		return new ModelAndView("deletionSuccessPage");
	}
	@RequestMapping("/deleteAccount")
	public ModelAndView deleteAccountAction(@ModelAttribute PostpaidAccount account) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException   {
		try{
			service.closeCustomerPostPaidAccount(-1,account.getMobileNo());}
		catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("deleteAccountPage","errMsg","Customer does not exist");
		}
		catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("deleteAccountPage","errMsg","Account does not exist");
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("deleteAccountPage","errMsg","Please try again");
		}
		return new ModelAndView("deletionSuccessPage");
	}

	@RequestMapping("/viewBillMethod")
	public ModelAndView viewBillAction(@Valid@ModelAttribute Bill bill , HttpServletRequest request,BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		if(result.hasErrors())
			return new ModelAndView("viewBillsPage","errMsg","Enter correct details");
		try{
			bill=service.getMobileBillDetails(-1, bill.getPostpaidAccount().getMobileNo(), bill.getBillMonth());
		}
		catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("viewBillsPage","errMsg","Customer does not Exist");
		}
		catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("viewBillsPage","errMsg","Account does not Exist");
		}
		catch (BillDetailsNotFoundException e) {
			return new ModelAndView("viewBillsPage","errMsg","Bill does not Exist");
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("viewBillsPage","errMsg","Please try Again");
		}
		return new ModelAndView("showBillPage","bill",bill);

	}

	@RequestMapping("/registerPlan")     //sign up
	public ModelAndView registerPlanAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		long mobileNo=0;
		try{
			mobileNo = service.openPostpaidMobileAccount(cust.getCustomerID(), plan.getPlanID());
			account = service.getPostPaidAccountDetails(cust.getCustomerID(), mobileNo);
			request.getSession().setAttribute("account1", account);
		}
		catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("planRegistrationPage", "errMsg","Account does not Exist" );
		}
		catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("planRegistrationPage", "errMsg","Customer does not Exist" );
		}
		catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("planRegistrationPage", "errMsg","Plan does not Exist" );
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("planRegistrationPage", "errMsg","Please try again" );
		}
		return new ModelAndView("planRegistrationSuccessPage", "account", service.getPostPaidAccountDetails(cust.getCustomerID(), mobileNo));

	}
	@RequestMapping("/anotherConnection")
	public ModelAndView registerAnotherConnectionAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		try {
			Customer customer=((PostpaidAccount)request.getSession().getAttribute("account")).getCustomer();
			long mobileNo =service.openPostpaidMobileAccount(customer.getCustomerID(), plan.getPlanID()) ;
			request.getSession().removeAttribute("account");
			account = service.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
			request.getSession().setAttribute("account", account);
		} catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("newConnectionPlanRegistrationPage","errMsg","Plan does not Exist");
		}
		catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("newConnectionPlanRegistrationPage","errMsg","Customer does not Exist");
		}
		catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("newConnectionPlanRegistrationPage","errMsg","Account does not Exist");
		}
		catch (BillingServicesDownException e) {
			return new ModelAndView("newConnectionPlanRegistrationPage","errMsg","Please try Again");
		}
		return new ModelAndView("newConnectionSuccessPage", "account", account);
	}

	@RequestMapping("/loginCustomer")
	public ModelAndView loginCustomerAction(@RequestParam("mobileNo") long mobileNo,HttpServletRequest request,HttpServletResponse response) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, IOException {
		try {
			account1 = service.getPostPaidAccountDetails(0, mobileNo);
		} catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("loginPage","errMsg","Enter Correct Mobile Number");
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("loginPage","errMsg","Customer does not Exist");
		} catch (BillingServicesDownException e) {
			return new ModelAndView("loginPage","errMsg","Please try Again");
		}
		request.getSession().setAttribute("account", account1);
		return new ModelAndView("loginSuccessPage");
	}

	@RequestMapping("/loginRegisterPlan")
	public ModelAndView loginRegisterPlanAction(@ModelAttribute Plan plan,HttpServletRequest request) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount loginAccount;
		try{
			loginAccount = (PostpaidAccount) request.getSession().getAttribute("account");
			service.changePlan(0, loginAccount.getMobileNo(), plan.getPlanID());
			loginAccount = service.getPostPaidAccountDetails(0, loginAccount.getMobileNo());
		}catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("loginPlanRegistration","errMsg","Plan does not Exist");
		}catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("loginPlanRegistration","errMsg","Customer does not Exist");
		}catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("loginPlanRegistration","errMsg","Account does not Exist");
		}catch (BillingServicesDownException e) {
			return new ModelAndView("loginPlanRegistration","errMsg","Please try Again");
		}
		return new ModelAndView("loginPlanRegistrationSuccessPage", "account1", loginAccount);
	}

	@RequestMapping("/generate")
	public ModelAndView generateBillAction(@Valid @ModelAttribute Bill bill,HttpServletRequest request) throws  InvalidBillMonthException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		try{
			PostpaidAccount loginAccount = (PostpaidAccount) request.getSession().getAttribute("account1");
			bill2 = service.generateMonthlyMobileBill(loginAccount.getCustomer().getCustomerID(), loginAccount.getMobileNo(), bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		}catch(CustomerDetailsNotFoundException e) {
			return new ModelAndView("generateBill","errMsg","Customer does not Exist");
		}catch(PostpaidAccountNotFoundException e) {
			return new ModelAndView("generateBill","errMsg","Account does not Exist");
		}catch(BillingServicesDownException e) {
			return new ModelAndView("generateBill","errMsg","Please try Again");
		}
		return new ModelAndView("billGenerated", "bill", bill2);
	}

	@RequestMapping("/loginGenerateBill")
	public ModelAndView loginGenerateBillAction(@Valid @ModelAttribute Bill bill,HttpServletRequest request) throws  InvalidBillMonthException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		try {
			PostpaidAccount demoAccount=(PostpaidAccount) request.getSession().getAttribute("account");
			bill2 = service.generateMonthlyMobileBill(demoAccount.getCustomer().getCustomerID(),
					demoAccount.getMobileNo(),bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(),
					bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
		}catch(CustomerDetailsNotFoundException e) {
			return new ModelAndView("loginGenerateBillPage","errMsg","Customer does not Exist");
		}catch(PostpaidAccountNotFoundException e) {
			return new ModelAndView("loginGenerateBillPage","errMsg","Account does not Exist");
		}catch(BillingServicesDownException e) {
			return new ModelAndView("loginGenerateBillPage","errMsg","Please try Again");
		}
		return new ModelAndView("billGenerated", "bill", bill2);	
	}
	@RequestMapping(value = "/allBillsPdfReport", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_PDF_VALUE )
	public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException {

		List<Bill> bills =  service.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);

		ByteArrayInputStream bis = GeneratePdfReport.billsReport(bills);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
	@RequestMapping("/displayCustomerPostPaidAccountAllBillDetails")
	public ModelAndView getDisplayCustomerPostPaidAccountAllBillDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo)  {
		List<Bill> bills;
		try {			
			bills = service.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
			service.validationCheck(customerID, mobileNo);
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("customerBillsPage", "errMsg", "Customer does not Exist");
		} catch (PostpaidAccountNotFoundException e) {
			return new ModelAndView("customerBillsPage", "errMsg", "Account does not Exist");
		} catch (BillingServicesDownException e) {
			return new ModelAndView("customerBillsPage", "errMsg", "Please try Again");
		} catch (PlanDetailsNotFoundException e) {
			return new ModelAndView("customerBillsPage", "errMsg", "Plan does not Exist");
		} catch (BillDetailsNotFoundException e) {
			return new ModelAndView("customerBillsPage", "errMsg", "Bill does not Exist");
		}
		return new ModelAndView("displayAllBillsPage", "bills", bills);
	}


}