package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class viewPlanDetailsStepDefinition {

	WebDriver driver;

	@Given("^User is on LoginSuccessPage$")
	public void user_is_on_LoginSuccessPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");		
		driver = new ChromeDriver();
		driver.get("http://localhost:5558/login");
		By by = By.name("mobileNo");
		WebElement searchTxt = driver.findElement(by);
		searchTxt.sendKeys("98156695");

		by = By.className("submit");
		searchTxt = driver.findElement(by);
		searchTxt.click();
	}

	@When("^User Clicks on Plan Details$")
	public void user_Clicks_on_Plan_Details() throws Throwable {
		By by = By.linkText("Plan Details");
		WebElement searchTxt = driver.findElement(by);
		searchTxt.click();
	}

	@Then("^Plan Details Page Opens$")
	public void plan_Details_Page_Opens() throws Throwable {
		String actual = driver.getTitle();
		String expected = "Plan Details";
		Assert.assertEquals(expected, actual);
	}
}
