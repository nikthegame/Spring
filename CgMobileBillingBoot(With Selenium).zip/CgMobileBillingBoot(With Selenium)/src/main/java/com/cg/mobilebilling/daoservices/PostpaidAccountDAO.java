package com.cg.mobilebilling.daoservices;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.mobilebilling.beans.PostpaidAccount;

public interface PostpaidAccountDAO extends JpaRepository<PostpaidAccount, Long> {
	@Modifying
	@Transactional
	@Query(value="delete from postpaid_Account where mobile_no=?1",nativeQuery=true)
	public void deleteAccount(long mobileNo);
	
}
