package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.mobilebilling.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class loginStepDefinition {
	
	private WebDriver driver;
	private LoginPage loginPage;
	
	/*@Before
	public void setUpStepEnv1() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");		
	}*/
	
	@Given("^User is on loginPage$")
	public void user_is_on_loginPage() throws Throwable {	
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("http://localhost:5558/login");
	    loginPage = PageFactory.initElements(driver, LoginPage.class);
	   
	}

	@When("^User enter wrong credentials$")
	public void user_enter_wrong_credentials() throws Throwable {
	  /*By by = By.name("mobileNo");
	  WebElement searchTxt = driver.findElement(by);
	  searchTxt.sendKeys("12345678");
	  
	  by = By.className("submit");
	  searchTxt = driver.findElement(by);
	  searchTxt.click();*/
		loginPage.setMobileNo("12345678");
		loginPage.clickLogIn();
	}

	@Then("^Error messgae appears$")
	public void error_messgae_appears() throws Throwable {
	    /*By by = By.id("errMsg");
	    WebElement searchTxt = driver.findElement(by);
	    String actualMsg = searchTxt.getText();
	    String expectedMsg = "Enter Correct Mobile Number";
	    Assert.assertEquals(expectedMsg, actualMsg);*/
		String actual = loginPage.getActualErrMsg();
		String expected = "Enter Correct Mobile Number";
		Assert.assertEquals(expected, actual);
	}

	@When("^User enter valid credentials$")
	public void user_enter_valid_credentials() throws Throwable {
		/*By by = By.name("mobileNo");
		  WebElement searchTxt = driver.findElement(by);
		  searchTxt.sendKeys("98156695");
		  
		  by = By.className("submit");
		  searchTxt = driver.findElement(by);
		  searchTxt.click();*/
		loginPage.setMobileNo("98156695");
		loginPage.clickLogIn();		
	}

	@Then("^User should be able to login$")
	public void user_should_be_able_to_login() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Login Successful";
	    Assert.assertEquals(expectedTitle, actualTitle);	   
	    driver.close();
	}
}
