package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public interface BankingService {
	Customer openAccount(String customerName,String emailId,String address,String pancard,String accountType,float accountBalance,String securityAnswer)
			throws BankingServicesDownException;
	Customer openAccount(Customer customer,Account account);
	float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException,BankingServicesDownException;
	float withdrawAmount(long accountNo,float amount)
			throws InsufficientAmountException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException;
	float fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException  ;
	Customer getCustomerDetails(long customerId)
			throws  AccountNotFoundException,BankingServicesDownException;
	List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException;
	List<Account> getAllAccountDetails()
			throws BankingServicesDownException;	
	List<Transaction> getAllTransactionDetails()
			throws BankingServicesDownException,
			AccountNotFoundException;
	List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException, 
			AccountNotFoundException;
}