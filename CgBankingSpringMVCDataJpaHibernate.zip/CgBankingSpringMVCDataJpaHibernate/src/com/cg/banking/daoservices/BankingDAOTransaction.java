package com.cg.banking.daoservices;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.cg.banking.beans.Transaction;
public interface BankingDAOTransaction extends JpaRepository<Transaction, Integer>{
	@Query(value = "SELECT * FROM TRANSACTION WHERE ACCOUNT_ACCOUNTNO = ?1", nativeQuery = true)
	public List<Transaction> findAccountAllTransaction(long accountNo);
}
